#!/system/bin/sh

test "$(id -u)" != "0" && echo "Please grant root permission first" && exit

# Define delimiter
local IFS=$'\n'

# Output folder
folder="${0%/*}/RefreshRate"
test -d "$folder" && rm -rf "$folder"
mkdir -p "$folder"

# Output refresh rate command
for i in $(dumpsys display | grep 'DisplayModeRecord' )
do
level_id="$(echo $i | grep -wo 'id=[0-9].*[0-9],' | sed 's|id=||g;s|,.*||g' )"
cmd_id="$(($level_id - 1))"
fps_level="$(echo $i | grep -wo 'fps=.*[0-9]' | sed 's|fps=||g;s|\..*||g' )"
width="$(echo $i | grep -wo 'width=[0-9].*[0-9],' | sed 's|width=||g;s|,.*||g;s|height=[0-9].*[0-9]||g' )"
height="$(echo $i | grep -wo 'height=[0-9].*[0-9],' | sed 's|height=||g;s|,.*||g;s|width=[0-9].*[0-9]||g' )"
if test ! -e "$folder/$fps_level.sh" ;then
cat << key >> "$folder/$fps_level.sh"
#!/system/bin/sh
#@coolapk 10007
# Service method
# Run: dumpsys display | grep 'DisplayModeRecord'
# You will see "Level = (id - 1)"
# Use: service call SurfaceFlinger 1035 i32 <level> to set custom refresh rate.
# Refresh rate: $fps_level ($level_id)
# Level: $cmd_id
# Screen resolution: $width X $height
# Note: When Smart Refresh Rate is enabled, you cannot change refresh rate
# using "service call" or "settings". 
# Also conflicts with dfps (since dfps repeatedly writes these values).
# Command:
test "\$(id -u)" != "0" && echo "Please grant root permission first" && exit

service call SurfaceFlinger 1035 i32 $cmd_id
settings put secure support_highfps 1
settings put system peak_refresh_rate $fps_level
settings put system user_refresh_rate $fps_level
settings put system min_refresh_rate $fps_level
settings put system default_refresh_rate $fps_level
settings put system refresh_default_rate $fps_level
resetprop persist.vendor.dfps.level $fps_level
su -c cmd activity startservice -n com.miui.powerkeeper/.ui.framerate.FrameRateService >/dev/null 2>&1
key
else
cat << key >> "$folder/$fps_level($width X $height).sh"
test "\$(id -u)" != "0" && echo "Please grant root permission first" && exit

service call SurfaceFlinger 1035 i32 $cmd_id
settings put secure support_highfps 1
settings put system peak_refresh_rate $fps_level
settings put system user_refresh_rate $fps_level
settings put system min_refresh_rate $fps_level
settings put system default_refresh_rate $fps_level
settings put system refresh_default_rate $fps_level
resetprop persist.vendor.dfps.level $fps_level
key
fi
done

cat << key > "$folder/Restore.sh"
#!/system/bin/sh
#@coolapk 10007
# Service method
# Run: dumpsys display | grep 'DisplayModeRecord'
# You will see "Level = (id - 1)"
# Use: service call SurfaceFlinger 1035 i32 <level> to set custom refresh rate.
# Refresh rate: $fps_level ($level_id)
# Command:
test "\$(id -u)" != "0" && echo "Please grant root permission first" && exit
service call SurfaceFlinger 1035 i32 -1
settings delete secure support_highfps
settings delete system peak_refresh_rate
settings delete system user_refresh_rate
settings delete system min_refresh_rate
settings delete system default_refresh_rate
settings delete system refresh_default_rate
resetprop ro.vendor.smart_dfps.enable true
resetprop --delete persist.vendor.dfps.level
am force-stop com.miui.powerkeeper >/dev/null 2>&1
key







