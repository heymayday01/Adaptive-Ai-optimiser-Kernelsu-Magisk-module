#!/system/bin/sh
# Optimized initialization script with lightweight AI learning agent
# Target: Snapdragon 888 on Xiaomi 11X Pro
# - Modularized, idempotent, and logs actions
# - Adds a lightweight online-learning Python agent (if python3 exists)
# - Falls back to heuristics if python unavailable
# - Writes/reads simple JSON model at /data/local/tmp/perf_model.json
# - Generated profile application script: /data/local/tmp/ai_profile_apply.sh

MODDIR=${0%/*}
LOGFILE=/data/local/tmp/optimization.log
MODEL_FILE=/data/local/tmp/perf_model.json
AI_SCRIPT=/data/local/tmp/ai_agent.py
PROFILE_SCRIPT=/data/local/tmp/ai_profile_apply.sh

log() {
    TS="$(date +'%F %T' 2>/dev/null || echo "$(awk 'BEGIN{srand(); print srand()}')")"
    echo "$TS - $1" >> "$LOGFILE"
}

# require root
if [ "$(id -u)" != "0" ]; then
    echo "Please run as root." >&2
    log "Aborted: not root"
    exit 1
fi

# helper: safe resetprop (only write if different)
safe_resetprop() {
    key="$1"; val="$2"
    cur="$(getprop "$key" 2>/dev/null)"
    if [ "x$cur" != "x$val" ]; then
        if command -v resetprop >/dev/null 2>&1; then
            resetprop "$key" "$val" || log "resetprop failed: $key -> $val"
        else
            setprop "$key" "$val" || log "setprop failed: $key -> $val"
        fi
        log "Applied: $key = $val"
    else
        log "Skipped (already): $key = $val"
    fi
}

# gather metrics used for AI/heuristic
gather_metrics() {
    # CPU usage: sample /proc/stat
    if [ -r /proc/stat ]; then
        read cpu a b c d e f g h < /proc/stat || true
        idle1=$((d))
        tot1=$((a+b+c+d+e+f+g+h))
        sleep 0.25
        read cpu a b c d e f g h < /proc/stat || true
        idle2=$((d))
        tot2=$((a+b+c+d+e+f+g+h))
        cpu_usage=$((100 * ( (tot2 - tot1) - (idle2 - idle1) ) / ( (tot2 - tot1) + 1 ) ))
        [ "$cpu_usage" -lt 0 ] && cpu_usage=0
        [ "$cpu_usage" -gt 100 ] && cpu_usage=100
    else
        cpu_usage=0
    fi

    # Temp: read thermal zones and take max (in millidegrees sometimes)
    max_temp=0
    for t in /sys/class/thermal/thermal_zone*/temp; do
        if [ -r "$t" ]; then
            v=$(cat "$t" 2>/dev/null || echo 0)
            # normalize values: if > 1000 assume millidegree
            if [ "$v" -gt 1000 ]; then
                v=$((v/1000))
            fi
            [ "$v" -gt "$max_temp" ] && max_temp=$v
        fi
    done
    # Battery level
    bat=0
    if command -v dumpsys >/dev/null 2>&1; then
        bat=$(dumpsys battery | awk -F: '/level/{gsub(/ /,"",$2); print $2; exit}' || echo 0)
    fi

    echo "$cpu_usage,$max_temp,$bat"
}

# write Python AI agent to disk (only if python available)
write_ai_agent() {
    cat > "$AI_SCRIPT" << 'PY'
#!/usr/bin/env python3
"""
Lightweight online-learning agent (no external libs).
Inputs: cpu, temp, battery (all numeric)
Model: linear scores for profiles ['performance','balanced','battery']
Model file stored in JSON at MODEL_FILE (path provided as env var MODEL_FILE)
Outputs: writes a shell script at PROFILE_SCRIPT containing resetprop commands
Also updates model weights based on reward computed from metrics (lower cpu/temp and higher battery are good)
"""
import os, sys, json, math, time

MODEL_FILE = os.environ.get('MODEL_FILE','/data/local/tmp/perf_model.json')
PROFILE_SCRIPT = os.environ.get('PROFILE_SCRIPT','/data/local/tmp/ai_profile_apply.sh')
args = sys.argv[1:]
if len(args) < 3:
    print('error: need cpu temp battery', file=sys.stderr)
    sys.exit(2)
try:
    cpu = float(args[0])
    temp = float(args[1])
    bat = float(args[2])
except:
    cpu,temp,bat = 0.0,40.0,50.0

# normalize features to 0..1
cpu_n = max(0.0, min(1.0, cpu/100.0))
# assume temp range 25..100C
temp_n = (max(25.0, min(100.0, temp)) - 25.0) / (100.0-25.0)
bat_n = max(0.0, min(1.0, bat/100.0))
features = [1.0, cpu_n, temp_n, bat_n]

profiles = ['performance','balanced','battery']
# default weights: bias favors balanced
default_w = {
    'performance':[ -0.2, -0.5, -0.3, 0.5 ],
    'balanced':[ 0.2, -0.2, -0.1, 0.1 ],
    'battery':[ 0.5, 0.7, 0.6, -1.0 ]
}
# load model
if os.path.exists(MODEL_FILE):
    try:
        with open(MODEL_FILE,'r') as f:
            model = json.load(f)
    except Exception:
        model = {'w':default_w,'last':{}}
else:
    model = {'w':default_w,'last':{}}

# predict scores
scores = {}
for p in profiles:
    w = model['w'].get(p, default_w[p])
    s = sum(w[i]*features[i] for i in range(len(features)))
    scores[p]=s
# choose profile
chosen = max(scores.items(), key=lambda x:x[1])[0]

# compute a simple reward (higher is better): prefer lower cpu/temp and higher battery
reward = max(0.0, 1.0 - cpu_n - temp_n + bat_n)/2.0

# online update: simple gradient ascent to increase score of chosen profile proportional to reward
lr = 0.03
w = model['w'].get(chosen, default_w[chosen])
for i in range(len(w)):
    # update rule: w += lr*(reward - sigmoid(score)) * feature
    # use sigmoid of chosen score as baseline
    baseline = 1.0/(1.0+math.exp(-scores[chosen]))
    w[i] = w[i] + lr * (reward - baseline) * features[i]
model['w'][chosen]=w
model['last']={'cpu':cpu,'temp':temp,'bat':bat,'chosen':chosen,'time':time.time()}
try:
    with open(MODEL_FILE,'w') as f:
        json.dump(model,f)
except Exception:
    pass

# Prepare profile application commands (strings)
apply_lines = []
if chosen == 'performance':
    apply_lines.extend([
        'safe_resetprop persist.sys.cpu.performance_tuning "high"',
        'safe_resetprop persist.sys.gpu.boost "true"',
        'safe_resetprop persist.sys.ui.animation_speed "0.8"',
        'safe_resetprop persist.graphics.vulkan.enable "1"',
        'safe_resetprop persist.sys.hyperos.display.smoothness "ultra"',
    ])
elif chosen == 'balanced':
    apply_lines.extend([
        'safe_resetprop persist.sys.cpu.performance_tuning "balanced"',
        'safe_resetprop persist.sys.gpu.boost "false"',
        'safe_resetprop persist.sys.ui.animation_speed "1.0"',
        'safe_resetprop persist.graphics.vulkan.enable "1"',
        'safe_resetprop persist.sys.hyperos.display.smoothness "balanced"',
    ])
else: # battery
    apply_lines.extend([
        'safe_resetprop persist.sys.cpu.performance_tuning "battery"',
        'safe_resetprop persist.sys.gpu.boost "false"',
        'safe_resetprop persist.sys.ui.animation_speed "1.5"',
        'safe_resetprop persist.graphics.vulkan.enable "0"',
        'safe_resetprop persist.sys.hyperos.display.smoothness "conservative"',
    ])
# add some common safe props
apply_lines.append('safe_resetprop persist.sys.zram.enabled "true"')
apply_lines.append('safe_resetprop persist.sys.zram.compression_algorithm "lz4"')

# write PROFILE_SCRIPT
try:
    with open(PROFILE_SCRIPT,'w') as f:
        f.write('#!/system/bin/sh\n')
        f.write('# Auto-generated profile apply script\n')
        f.write('safe_resetprop() {\n')
        f.write('  key="$1"; val="$2"\n')
        f.write('  cur="$(getprop \"$key\" 2>/dev/null)"\n')
        f.write('  if [ "x$cur" != "x$val" ]; then\n')
        f.write('    if command -v resetprop >/dev/null 2>&1; then\n')
        f.write('      resetprop "$key" "$val" || echo "resetprop failed: $key -> $val"\n')
        f.write('    else\n')
        f.write('      setprop "$key" "$val" || echo "setprop failed: $key -> $val"\n')
        f.write('    fi\n')
        f.write('  fi\n')
        f.write('}\n')
        for line in apply_lines:
            f.write(line + '\n')
    os.chmod(PROFILE_SCRIPT, 0o755)
except Exception:
    print('error writing profile script', file=sys.stderr)

# Print chosen profile so shell can read it
print(chosen)
PY
    chmod 755 "$AI_SCRIPT" || true
    log "AI agent written to $AI_SCRIPT"
}

# fallback heuristic if python not available
heuristic_select() {
    read metrics <<EOF
$(gather_metrics)
EOF
    cpu=$(echo "$metrics" | cut -d, -f1)
    temp=$(echo "$metrics" | cut -d, -f2)
    bat=$(echo "$metrics" | cut -d, -f3)

    # simple thresholds
    if [ "$bat" -lt 30 ] || [ "$temp" -gt 55 ]; then
        echo battery
    elif [ "$cpu" -gt 65 ]; then
        echo performance
    else
        echo balanced
    fi
}

# Prepare: write AI agent if python3 exists
if command -v python3 >/dev/null 2>&1; then
    write_ai_agent
fi

# Gather current metrics
metrics=$(gather_metrics)
cpu=$(echo "$metrics" | cut -d, -f1)
temp=$(echo "$metrics" | cut -d, -f2)
bat=$(echo "$metrics" | cut -d, -f3)
log "Metrics: cpu=$cpu temp=$temp bat=$bat"

# Decide profile using python agent if available, else heuristic
profile=""
if command -v python3 >/dev/null 2>&1 && [ -f "$AI_SCRIPT" ]; then
    profile=$(python3 "$AI_SCRIPT" "$cpu" "$temp" "$bat" 2>>"$LOGFILE" | tr -d '\n')
    if [ -z "$profile" ]; then
        log "AI agent failed to choose profile; falling back"
        profile=$(heuristic_select)
    else
        log "AI agent chose profile: $profile"
    fi
else
    profile=$(heuristic_select)
    log "Heuristic chose profile: $profile"
fi

# Apply common props and profile-specific props (idempotent via safe_resetprop)
case "$profile" in
    performance)
        safe_resetprop persist.sys.cpu.performance_tuning "high"
        safe_resetprop persist.sys.gpu.boost "true"
        safe_resetprop persist.sys.ui.animation_speed "0.8"
        safe_resetprop persist.graphics.vulkan.enable "1"
        safe_resetprop persist.sys.hyperos.display.smoothness "ultra"
        ;;
    balanced)
        safe_resetprop persist.sys.cpu.performance_tuning "balanced"
        safe_resetprop persist.sys.gpu.boost "false"
        safe_resetprop persist.sys.ui.animation_speed "1.0"
        safe_resetprop persist.graphics.vulkan.enable "1"
        safe_resetprop persist.sys.hyperos.display.smoothness "balanced"
        ;;
    battery)
        safe_resetprop persist.sys.cpu.performance_tuning "battery"
        safe_resetprop persist.sys.gpu.boost "false"
        safe_resetprop persist.sys.ui.animation_speed "1.5"
        safe_resetprop persist.graphics.vulkan.enable "0"
        safe_resetprop persist.sys.hyperos.display.smoothness "conservative"
        ;;
    *)
        log "Unknown profile: $profile - applying balanced defaults"
        safe_resetprop persist.sys.cpu.performance_tuning "balanced"
        ;;
esac

# Common safety and features (only applied if not already set)
safe_resetprop persist.sys.zram.enabled "true"
safe_resetprop persist.sys.zram.compression_algorithm "lz4"
safe_resetprop persist.sys.swappiness "60"
safe_resetprop persist.sys.enable_fstrim "true"

# Apply 5G/Bluetooth/audio optimizations (kept but deduplicated)
safe_resetprop persist.vendor.radio.always_on_nr "true"
safe_resetprop persist.radio.nr_nsa_combined_enable "1"
safe_resetprop persist.radio.nr.sa_on_5g_network "1"
safe_resetprop ro.vendor.audio.feature.a2dp_offload.supported "1"
safe_resetprop ro.vendor.audio.offload.buffer.size.kb "64"
safe_resetprop ro.vendor.audio.a2dp.codec "AAC,aptX,aptX-HD,LDAC"
safe_resetprop persist.vendor.btstack.a2dp_offload_cap "true"

# Post notification (best-effort)
if su -lp 2000 -c "cmd notification post -S bigtext -t 'Performance Mode' 'System' 'Performance optimizations applied (profile: $profile)'." >/dev/null 2>&1; then
    log "Notification posted"
else
    log "Notification failed or not supported"
fi

# Ensure auxiliary init script executable and attempt run
if [ -x "$MODDIR/init/init.sh" ]; then
    chmod 755 "$MODDIR/init/init.sh" 2>/dev/null || true
    if ! su -c "$MODDIR/init/init.sh"; then
        log "Failed to execute $MODDIR/init/init.sh"
    else
        log "Executed $MODDIR/init/init.sh"
    fi
else
    log "No init script at $MODDIR/init/init.sh or not executable"
fi

log "Optimization complete (profile: $profile)"

echo "Optimization applied (profile: $profile)"

exit 0
