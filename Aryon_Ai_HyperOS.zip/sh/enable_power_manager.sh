#!/system/bin/sh

am kill com.miui.powerkeeper

pm enable com.miui.powerkeeper
pm unsuspend com.miui.powerkeeper
pm unhide com.miui.powerkeeper
pm install-existing --user 0 com.miui.powerkeeper
