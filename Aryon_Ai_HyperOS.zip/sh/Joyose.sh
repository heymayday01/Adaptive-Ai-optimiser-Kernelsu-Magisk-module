#!/system/bin/sh

function lock_folder(){
export PATH=$(magisk --path)/.magisk/busybox:$PATH
if test -d "${1}" ;then
	chmod -R 0000 "${1}"
	rm -rf ${1}/* 2>/dev/null
	chmod -R 0000 "${1}"
	chown -R root:root "${1}"
	chcon -R u:object_r:system_file:s0 "${1}"
fi
}

#两个锁帧文件夹
#如果你懂得修改，那么请你自己修改这个文件夹，并注释掉这两行，或者删除此脚本。
lock_folder "/data/system/migt"
lock_folder "/data/system/mcd"

