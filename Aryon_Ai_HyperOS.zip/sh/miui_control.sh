#屏蔽MIUI 云控
#防止MIUI 下发云控给电量和性能，进行负优化。
#来自@酷安 OLX_新的分歧 大佬
#地址
ip_list="
cc.sys.intl.xiaomi.com
cc.sys.miui.com
ccc.sys.intl.xiaomi.com
ccc.sys.miui.com
ccc.sys.rus.xiaomi.com
jupiter.intl.sys.miui.com
jupiter.rus.sys.miui.com
jupiter.sys.miui.com
preview-jupiter.sys.miui.com
rom.pt.miui.srv
staging.ccc.sys.xiaomi.srv
"

for i in $ip_list
do
	#屏蔽
	iptables -A OUTPUT -m string --string "$i" --algo bm --to 65535 -j DROP
	iptables -A INPUT -m string --string "$i" --algo bm --to 65535 -j DROP
	#恢复
	#iptables -D OUTPUT -m string --string "$i" --algo bm --to 65535 -j DROP
	#iptables -D INPUT -m string --string "$i" --algo bm --to 65535 -j DROP
done

#允许系统应用联网
#resetprop persist.sys.sc_allow_conn false
#setprop persist.sys.sc_allow_conn false


