test "$(id -u)" != "0" && echo "请您先授予root 权限执行" && exit
service call SurfaceFlinger 1035 i32 1
settings put secure support_highfps 1
settings put system peak_refresh_rate 
settings put system user_refresh_rate 120
settings put system min_refresh_rate 120
settings put system default_refresh_rate 120
settings put system refresh_default_rate 120
resetprop persist.vendor.dfps.level 120
