#!/system/bin/sh
for i in /data/adb/modules/init/sh/*.sh ;do
chmod 777 $i
su -c $i
done

for i in /data/adb/modules/init/sh/* ;do
chmod 777 $i
su -c $i
done